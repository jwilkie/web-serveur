import { db } from '../db/db.js';

/**
 * Retourne la liste des tâches à faire.
 * @returns La liste des tâches à faire.
 */
export async function getTaches() {
    const taches = await db.all(`SELECT * FROM tache`);
    
    return taches;
}

/**
 * Ajoute une tache à faire dans la liste.
 * @param {string} texte Texte de la nouvelle tâche à faire.
 * @returns L'identifiant de la nouvelle tâche créé.
 */
export async function addTache(texte) {
    const resultat = await db.run(
        `INSERT INTO tache(texte, est_fait)
        VALUES(?, 0)`,
        [texte]
    );

    return resultat.lastID;
}

/**
 * Coche ou décoche une tâche dans la liste de tâches à faire.
 * @param {number} idTache Identifiant de la tâche à cocher ou décocher dans la liste.
 */
export async function cocheTache(idTache) {
    await db.run(
        `UPDATE tache
        SET est_fait = NOT est_fait
        WHERE id_tache = ?`,
        [idTache]
    );
}