import { isCourrielValide, isMotDePasseValide } from './validation.js';

const inputCourriel = document.getElementById('input-courriel');
const inputMotDePasse = document.getElementById('input-mot-de-passe');
const formAuth = document.getElementById('form-auth');
const erreurs = document.getElementById('erreurs');

async function inscription(event) {
    event.preventDefault();

    // Les noms des variables doivent être les mêmes
    // que celles spécifié dans les configuration de
    // passport dans le fichier "auth.js"
    const data = {
        courriel: inputCourriel.value,
        motDePasse: inputMotDePasse.value
    };

    // Réinitialiser les erreurs
    erreurs.innerText = '';

    // Validation cliente
    if(!isCourrielValide(data.courriel)) {
        erreurs.innerText = 'Le courriel n\'est pas valide.';
        return;
    }

    if(!isMotDePasseValide(data.motDePasse)) {
        erreurs.innerText = 'Le mot de passe doit contenir au moins 8 caractères.';
        return;
    }

    // Envoyer la requête au serveur
    let response = await fetch('/api/inscription', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    });

    // Traitement de la réponse
    if (response.ok) {
        // Si l'authentification est réussi, on
        // redirige vers une autre page
        window.location.replace('/connexion');
    }
    else if(response.status === 409) {
        erreurs.innerText = 'Un compte avec ce courriel existe déjà.';
    }   
};

formAuth.addEventListener('submit', inscription);