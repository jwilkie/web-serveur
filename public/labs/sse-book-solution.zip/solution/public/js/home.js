import { areAuthorsValid, areCategoriesValid, isIsbnValid, isNbPageValid, isSummaryValid, isTitleValid } from './validation.js';

// Recherche d'élément dans la page HTML
const listBooks = document.getElementById('list-books');
const formBooks = document.getElementById('form-books');
const errorSelector = document.getElementById('error-selector');
const errorIsbn = document.getElementById('error-isbn');
const errorTitle = document.getElementById('error-title');
const errorNbPages = document.getElementById('error-nb-pages');
const errorSummary = document.getElementById('error-summary');
const errorAuthors = document.getElementById('error-authors');
const errorCategories = document.getElementById('error-categories');

/**
 * Valide si le livre passé en paramètre est valide. S'il n'est pas valide, 
 * affiche les messages d'erreurs dans l'interface graphique.
 * @param {Object} book Un livre à valider.
 * @returns Une valeur indiquant si le livre en paramètre est valide ou non.
 */
function isBookValid(book) {
    let isValid = true;

    if(!isIsbnValid(book.isbn)) {
        errorIsbn.innerText = 'Le ISBN entré n\'est pas valide.';
        isValid = false;
    }

    if(!isTitleValid(book.title)) {
        errorTitle.innerText = 'Le titre entré n\'est pas valide.';
        isValid = false;
    }

    if(!isNbPageValid(book.nbPages)) {
        errorNbPages.innerText = 'Le nombre de pages entré n\'est pas valide.';
        isValid = false;
    }

    if(!isSummaryValid(book.summary)) {
        errorSummary.innerText = 'Le sommaire entré n\'est pas valide.';
        isValid = false;
    }

    if(!areAuthorsValid(book.authors)) {
        errorAuthors.innerText = 'Le ou les auteurs entrés ne sont pas valide. S\'il y a plusieurs auteurs, assurez-vous de séparer leur nom par des virgules.';
        isValid = false;
    }

    if(!areCategoriesValid(book.categories)) {
        errorCategories.innerText = 'Le ou les catégories entrées ne sont pas valide. S\'il y a plusieurs catégories, assurez-vous de séparer leur nom par des virgules.';;
        isValid = false;
    }

    return isValid;
}

/**
 * Enlève toutes les erreurs affichées de l'interface graphique.
 */
function clearErrors() {
    errorSelector.innerText = '';
    errorIsbn.innerText = '';
    errorTitle.innerText = '';
    errorNbPages.innerText = '';
    errorSummary.innerText = '';
    errorAuthors.innerText = '';
    errorCategories.innerText = '';
}

/**
 * Crée un <option> dans le <select> avec le titre et le ISBN du livre.
 * @param {string} isbn Le ISBN du livre.
 * @param {string} title Le titre du livre.
 */
function addBookClient(isbn, title) {
    const option = document.createElement('option');
    option.innerText = `(${isbn}) - ${title}`;
    option.value = isbn;
    listBooks.append(option);
}

/**
 * Mets à jour un livre dans l'interface graphique.
 * @param {string} isbn Le ISBN du livre à modifier.
 * @param {string} newIsbn Le nouvel ISBN du livre à modifier.
 * @param {string} newTitle Le nouveau titre du livre à modifier.
 */
function updateBookClient(isbn, newIsbn, newTitle) {
    const option = listBooks.querySelector(`option[value="${isbn}"]`);
    option.innerText = `(${newIsbn}) - ${newTitle}`;
    option.value = newIsbn;
}

/**
 * Supprime un livre dans l'interface graphique
 * @param {string} isbn Le ISBN du livre à supprimer
 */
function deleteBookClient(isbn) {
    listBooks.querySelector(`option[value="${isbn}"]`).remove();
}

/**
 * Détecte le changement de sélection du <select> contenant les livres.
 * @param {Event} event Évènement de changement du <select> contenant les livres.
 */
async function getBookServer(event) {
    // Si Aucun livre n'est sélectionné, on vide le formulaire
    if(!event.currentTarget.value) {
        formBooks.reset();
        return;
    }

    // On enlève les erreurs s'il y en avait
    clearErrors();

    // Si un livre est sélectionné, on va chercher son information sur le 
    // serveur avec son ISBN.
    const response = await fetch(`/api/book?isbn=${event.currentTarget.value}`);

    // Traitement de la réponse
    if(response.ok) {
        const book = await response.json();

        // On ajoute les données du livre dans le formulaire
        formBooks.isbn.value = book.isbn;
        formBooks.title.value = book.title;
        formBooks.nbPages.value = book.nb_pages;
        formBooks.summary.value = book.summary;
        formBooks.authors.value = book.authors.join(', ');
        formBooks.categories.value = book.categories.join(', ');
    }
}

/**
 * Ajoute un livre dans la bibliothèque de livre sur le serveur.
 */
async function addBookServer() {
    // Préparation des données
    const data = {
        book: {
            isbn: formBooks.isbn.value,
            title: formBooks.title.value,
            nbPages: Number(formBooks.nbPages.value),
            summary: formBooks.summary.value,
            authors: formBooks.authors.value.split(',').map((author) => author.trim()),
            categories: formBooks.categories.value.split(',').map((category) => category.trim())
        }
    };
    
    // Validation
    clearErrors();
    if(!isBookValid(data.book)) {
        return;
    }

    // Envoyer la requête pour supprimer un livre de la bibliothèque
    const response = await fetch('/api/book', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    });

    // Traitement de la réponse
    if(response.ok) {
        // On n'ajoute plus le livre dans l'interface graphique puisqu'il est 
        // ajouté par le SSE
        formBooks.reset();
    }
}

/**
 * Met à jour un livre dans la bibliothèque de livre sur le serveur.
 */
async function updateBookServer() {
    // Préparation des données
    const data = {
        isbn: listBooks.value,
        book: {
            isbn: formBooks.isbn.value,
            title: formBooks.title.value,
            nbPages: Number(formBooks.nbPages.value),
            summary: formBooks.summary.value,
            authors: formBooks.authors.value.split(',').map((author) => author.trim()),
            categories: formBooks.categories.value.split(',').map((category) => category.trim())
        }
    };

    // Validation
    clearErrors();
    if(!isIsbnValid(data.isbn)) {
        errorSelector.innerText = 'Veuillez sélectionner un livre à modifier';
        return;
    }

    if(!isBookValid(data.book)) {
        return;
    }

    // Envoyer la requête pour modifier un livre de la bibliothèque
    const response = await fetch('/api/book', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    });

    // Traitement de la réponse
    if(response.ok) {
        // On ne modifie plus le livre dans l'interface graphique puisqu'il est 
        // modifié par le SSE
        formBooks.reset();
    }
}

/**
 * Supprime un livre dans la bibliothèque de livre sur le serveur.
 */
async function deleteBookServer() {
    // Préparation des données
    const data = {
        isbn: listBooks.value
    };

    // Validation
    clearErrors();
    if(!isIsbnValid(data.isbn)) {
        errorSelector.innerText = 'Veuillez sélectionner un livre à supprimer';
        return;
    }

    // Envoyer la requête pour supprimer un livre de la bibliothèque
    const response = await fetch('/api/book', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    });

    // Traitement de la réponse
    if(response.ok) {
        // On ne supprime plus le livre dans l'interface graphique puisqu'il est 
        // supprimé par le SSE
        formBooks.reset();
    }
}

/**
 * Détecte la soumission du formulaire et détermine quel bouton/opération a 
 * été choisi par l'utilisateur.
 * @param {SubmitEvent} event Évènement de soumission du formulaire.
 */
function handleSubmit(event) {
    event.preventDefault();

    if(event.submitter.name === 'add') {
        addBookServer();
    }
    else if(event.submitter.name === 'update') {
        updateBookServer();
    }
    else if(event.submitter.name === 'delete') {
        deleteBookServer();
    }
}

// Code à exécuter au démarrage de la page
// Détecter le changement de sélection de la liste déroulante
listBooks.addEventListener('change', getBookServer);

// Détecter la soumission du formulaire
formBooks.addEventListener('submit', handleSubmit);

// Connexion au canal SSE
const source = new EventSource('/api/sse');

// Ajout des livres à la liste en temps réel
source.addEventListener('add-book', (event) => {
    const data = JSON.parse(event.data);
    addBookClient(data.isbn, data.title);
});

// Suppression des livres de la liste en temps réel
source.addEventListener('delete-book', (event) => {
    const data = JSON.parse(event.data);
    deleteBookClient(data.isbn);
});

// Modification des livres dans la liste en temps réel
source.addEventListener('modify-book', (event) => {
    const data = JSON.parse(event.data);
    updateBookClient(data.isbn, data.newIsbn, data.newTitle);
});

