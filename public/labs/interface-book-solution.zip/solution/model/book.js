/**
 * Liste des livres disponible à notre bibliothèque.
 */
let books = [
    {
        isbn: "978-2070518425",
        title: "Harry Potter à l'école des sorciers",
        nbPages: 308,
        summary: "Sauvé de la négligence scandaleuse de sa tante et de son oncle, un jeune garçon avec un grand destin prouve sa valeur tout en fréquentant l'école des sorciers et des sorcières de Poudlard",
        authors: ["J.K. Rowling"],
        categories: ["fantastique", "junior"],
    },
    {
        isbn: "978-0316452960",
        title: "The Witcher - The Tower of Swallows",
        nbPages: 464,
        summary: "The world is at war and the prophesied savior is nowhere to be found. The Witcher, Geralt of Rivia, races to find her in the fourth novel of Andrzej Sapkowski's groundbreaking epic fantasy series that inspired the hit Netflix show and the blockbuster video games.",
        authors: ["Andrzej Sapkowski"],
        categories: ["fantastique", "action", "adulte"],
    }
]

/**
 * Retourne la liste de tous les titres de livres avec leur ISBN dans notre bibliothèque.
 * @returns Une liste de titre de livre avec leur ISBN.
 */
export function getAllISBNAndTitle() {
    // Autre façon de faire plus courte
    // return books.map(book => ({
    //     isbn: book.isbn,
    //     titre: book.title
    // }));

    let list = []
    for(let book of books) {
        list.push({
            isbn: book.isbn,
            title: book.title
        });
    }

    return list;
}

/**
 * AJoute un livre à la liste des livres de notre bibliothèque.
 * @param {object} book Un objet représentant un livre.
 */
export function addBook(book) {
    books.push(book);
}

/**
 * Retourne un livre de notre bibliothèque en fonction de son ISBN.
 * @param {string} isbn Le numéro ISBN du livre à rechercher.
 * @returns Le livre correspondant à l'ISBN ou null si aucun livre ne correspond.
 */
export function getBookByISBN(isbn) {
    // Autre façon de faire plus courte
    // return books.find(book => book.isbn === isbn);

    for(let book of books) {
        if(book.isbn === isbn) {
            return book;
        }
    }

    return null;
}

/**
 * Modifie un livre de notre bibliothèque en fonction de son ISBN. Si le livre n'existe pas, il est ajouté.
 * @param {string} isbn Le numéro ISBN du livre à modifier. 
 * @param {object} newBook Un objet représentant le livre modifié.
 */
export function modifyBook(isbn, newBook) {
    // Autre façon de faire
    // const index = books.findIndex(book => book.isbn === isbn);
    // if(index !== -1) {
    //     books[index] = newBook;
    // } 
    // else {
    //     addBook(newBook);
    // }

    for(let i = 0; i < books.length; i++) {
        if(books[i].isbn === isbn) {
            books[i] = newBook;
            return;
        }
    }

    addBook(newBook);
}

/**
 * Supprime un livre de notre bibliothèque en fonction de son ISBN.
 * @param {string} isbn Le numéro ISBN du livre à supprimer.
 */
export function deleteBook(isbn) {
    // Autre façon de faire
    // const index = books.findIndex(book => book.isbn === isbn);
    // if(index !== -1) {
    //     books.splice(index, 1);
    // }
    for(let i = 0; i < books.length; i++) {
        if(books[i].isbn === isbn) {
            books.splice(i, 1);
            return;
        }
    }
}
