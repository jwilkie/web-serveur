// Recherche d'élément dans la page HTML
const listBooks = document.getElementById('list-books');
const formBooks = document.getElementById('form-books');

/**
 * Crée un <option> dans le <select> avec le titre et le ISBN du livre.
 * @param {string} isbn Le ISBN du livre.
 * @param {string} title Le titre du livre.
 */
function addBookClient(isbn, title) {
    const option = document.createElement('option');
    option.innerText = `(${isbn}) - ${title}`;
    option.value = isbn;
    listBooks.append(option);
}

/**
 * Recherche tous les ISBN et titre des livres disponible dans la liste sur le 
 * serveur.
 */
async function getBooksServer() {
    
    // À programmer ...

}

/**
 * Détecte le changement de sélection du <select> contenant les livres et va 
 * chercher les informations du livre sur le serveur pour remplir le 
 * formulaire avec les bonnes informations du livre sélectionné.
 * @param {Event} event Évènement de changement du <select> contenant les livres.
 */
async function getBookServer(event) {
    // Si Aucun livre n'est sélectionné, on vide le formulaire
    if(!event.currentTarget.value) {
        formBooks.reset();
        return;
    }


    // Le reste à programmer ...

}

/**
 * Ajoute un livre dans la bibliothèque de livre sur le serveur.
 */
async function addBookServer() {

    // À programmer ...

}

/**
 * Met à jour un livre dans la bibliothèque de livre sur le serveur.
 */
async function updateBookServer() {
    
    // À programmer ...

}

/**
 * Supprime un livre dans la bibliothèque de livre sur le serveur.
 */
async function deleteBookServer() {
    
    // À programmer ...

}

/**
 * Détecte la soumission du formulaire et détermine quel bouton/opération a 
 * été choisi par l'utilisateur.
 * @param {SubmitEvent} event Évènement de soumission du formulaire.
 */
function handleSubmit(event) {
    event.preventDefault();

    if(event.submitter.name === 'add') {
        addBookServer();
    }
    else if(event.submitter.name === 'update') {
        updateBookServer();
    }
    else if(event.submitter.name === 'delete') {
        deleteBookServer();
    }
}

// Code à exécuter au démarrage de la page
// Aller chercher les livres sur le serveur
getBooksServer();

// Détecter le changement de sélection de la liste déroulante
listBooks.addEventListener('change', getBookServer);

// Détecter la soumission du formulaire
formBooks.addEventListener('submit', handleSubmit);
