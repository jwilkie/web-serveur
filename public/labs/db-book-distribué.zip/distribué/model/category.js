import { db } from '../db/db.js';

/**
 * Retourne les catégories d'un livre.
 * @param {string} isbn Le numéro ISBN du livre duquel on veut les catégories.
 */
export async function getCategoriesByISBN(isbn) {
    // À compléter...

}

/**
 * Recherche l'identifiant d'une catégorie. Si la catégorie n'existe pas, on 
 * la crée et on retourne l'identifiant de cette nouvelle catégorie.
 * @param {string} name Le nom de la catégory à rechercher ou à ajouter.
 * @returns L'identifiant de la catégorie.
 */
export async function getOrAddCategory(name) {
    // À compléter...
    
}
