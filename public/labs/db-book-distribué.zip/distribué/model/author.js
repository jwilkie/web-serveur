import { db } from '../db/db.js';

/**
 * Retourne les auteurs d'un livre.
 * @param {string} isbn Le numéro ISBN du livre duquel on veut le ou les auteurs.
 */
export async function getAuthorsByISBN(isbn) {
    // À compléter...

}

/**
 * Recherche l'identifiant d'un auteur. Si l'auteur n'existe pas, on le crée 
 * et on retourne l'identifiant de ce nouvel auteur.
 * @param {string} name Le nom de l'auteur à rechercher ou à ajouter.
 * @returns L'identifiant de l'auteur.
 */
export async function getOrAddAuthor(name) {
    // À compléter...
    
}
