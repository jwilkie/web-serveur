/**
 * Valide un ISBN.
 * @param {string} isbn Le ISBN à valider.
 * @returns Une valeur indiquant si le ISBN est valide ou non.
 */
export const isIsbnValid = (isbn) => 
    typeof isbn === 'string' && 
    (
        isbn.replace('-', '').length === 10 ||
        isbn.replace('-', '').length === 13
    );

/**
 * Valide un titre.
 * @param {string} title Le titre à valider.
 * @returns Une valeur indiquant si le titre est valide ou non.
 */
export const isTitleValid = (title) => 
    typeof title === 'string' &&
    title !== '';

/**
 * Valide un nombre de pages.
 * @param {string} nbPages Le nombre de pages à valider.
 * @returns Une valeur indiquant si le nombre de pages est valide ou non.
 */
export const isNbPageValid = (nbPages) => 
    typeof nbPages === 'number' &&
    Number.isInteger(nbPages) &&
    nbPages > 0;

/**
 * Valide un sommaire.
 * @param {string} summary Le sommaire à valider.
 * @returns Une valeur indiquant si le sommaire est valide ou non.
 */
export const isSummaryValid = (summary) => 
    typeof summary === 'string' &&
    summary !== '';

/**
 * Valide une liste d'auteurs.
 * @param {string} authors La liste d'auteurs à valider.
 * @returns Une valeur indiquant si la liste d'auteurs est valide ou non.
 */
export const areAuthorsValid = (authors) => 
    Array.isArray(authors) &&
    authors.length > 0 &&
    authors.every((author) => 
        typeof author === 'string' &&
        author !== ''
    );

/**
 * Valide une liste de catégories.
 * @param {string} categories La liste de catégories à valider.
 * @returns Une valeur indiquant si la liste de catégories est valide ou non.
 */
export const areCategoriesValid = (categories) => 
    Array.isArray(categories) &&
    categories.length > 0 &&
    categories.every((category) => 
        typeof category === 'string' &&
        category !== ''
    );