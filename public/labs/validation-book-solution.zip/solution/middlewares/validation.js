import { areAuthorsValid, areCategoriesValid, isIsbnValid, isNbPageValid, isSummaryValid, isTitleValid } from '../public/js/validation.js';

/**
 * Middleware validant le livre dans le body.
 * @param {import("express").Request} request Objet de requête HTTP.
 * @param {import("express").Response} response  Objet de réponse HTTP.
 * @param {import("express").NextFunction} next Fonction pour passer au prochain middleware.
 */
export function bookIsValid(request, response, next) {
    if (isBookValid(request.body.book)) {
        return next();
    }

    response.status(400).end();
}

/**
 * Middleware validant le ISBN dans le body.
 * @param {import("express").Request} request Objet de requête HTTP.
 * @param {import("express").Response} response  Objet de réponse HTTP.
 * @param {import("express").NextFunction} next Fonction pour passer au prochain middleware.
 */
export function isbnIsValid(request, response, next) {
    if (isIsbnValid(request.body.isbn)) {
        return next();
    }

    response.status(400).end();
}

/**
 * Middleware validant le ISBN dans le query.
 * @param {import("express").Request} request Objet de requête HTTP.
 * @param {import("express").Response} response  Objet de réponse HTTP.
 * @param {import("express").NextFunction} next Fonction pour passer au prochain middleware.
 */
export function isbnQueryIsValid(request, response, next) {
    if (isIsbnValid(request.query.isbn)) {
        return next();
    }

    response.status(400).end();
}

/**
 * Valide le livre.
 * @param {string} book Le livre à valider.
 * @returns Une valeur indiquant si le livre est valide ou non.
 */
const isBookValid = (book) =>
    isIsbnValid(book.isbn) &&
    isTitleValid(book.title) &&
    isNbPageValid(book.nbPages) &&
    isSummaryValid(book.summary) &&
    areAuthorsValid(book.authors) &&
    areCategoriesValid(book.categories);
