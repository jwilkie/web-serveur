import { isIdValid, isTexteValid } from '../public/js/validation.js'

/**
 * Middleware validant le texte fourni dans le body.
 * @param {import("express").Request} request 
 * @param {import("express").Response} response 
 * @param {import("express").NextFunction} next 
 */
export function texteEstValide(request, response, next) {
    if(isTexteValid(request.body.texte)) {
        return next();
    }

    response.status(400).end();
}

/**
 * Middleware validant le id de la tâche fourni dans le body.
 * @param {import("express").Request} request 
 * @param {import("express").Response} response 
 * @param {import("express").NextFunction} next 
 */
export function idTacheEstValide(request, response, next) {
    if(isIdValid(request.body.idTache)) {
        return next();
    }

    response.status(400).end();
}