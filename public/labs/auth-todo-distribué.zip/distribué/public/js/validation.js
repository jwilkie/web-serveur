/**
 * Valide le texte passé en paramètre.
 * @param {string} texte Texte à valider.
 * @returns Une valeur indiquant si le texte est valide ou non.
 */
export const isTexteValid = (texte) => 
    typeof texte === 'string' &&
    texte !== '';

/**
 * Valide l'identifiant passé en paramètre.
 * @param {number} id Identifiant à valider.
 * @returns Une valeur indiquant si l'identifiant est valide ou non.
 */
export const isIdValid = (id) => 
    typeof id === 'number' &&
    Number.isInteger(id) &&
    id > 0;