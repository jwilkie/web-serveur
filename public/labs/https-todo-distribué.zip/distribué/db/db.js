import { open } from 'sqlite';
import sqlite3 from 'sqlite3';
import { existsSync } from 'node:fs';

// Vérifie si le fichier de base de données est 
// nouveau (n'existe pas encore)
const IS_NEW = !existsSync(process.env.DB_FILE);

// Connexion à la base de données. Vous devez 
// spécifier le nom du fichier de base de données 
// dans le fichier .env
let db = await open({
    filename: process.env.DB_FILE,
    driver: sqlite3.Database
});

// Création de la table si elle n'existe pas, on 
// peut écrire du code SQL pour initialiser les 
// tables et données dans la fonction exec()
if(IS_NEW) {
    await db.exec(
        `CREATE TABLE tache(
            id_tache INTEGER PRIMARY KEY,
            texte TEXT NOT NULL,
            est_fait INTEGER NOT NULL
        );

        CREATE TABLE utilisateur(
            id_utilisateur INTEGER PRIMARY KEY,
            courriel TEXT NOT NULL UNIQUE,
            mot_de_passe TEXT NOT NULL,
            niveau_acces INTEGER DEFAULT 1
        );
        
        INSERT INTO tache(texte, est_fait)
        VALUES('Suivre le cours', 1);
        INSERT INTO tache(texte, est_fait)
        VALUES('Faire le laboratoire', 0);`
    );
}

export { db }