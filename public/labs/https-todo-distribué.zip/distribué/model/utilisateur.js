import { db } from '../db/db.js';
import bcrypt from 'bcrypt';

/**
 * Ajoute un utilisateur dans la base de données.
 * @param {string} courriel Courriel de l'utilisateur.
 * @param {string} motDePasse Mot de passe de l'utilisateur.
 */
export async function addUtilisateur(courriel, motDePasse) {
    let motDePasseEncrypte = await bcrypt.hash(motDePasse, 10);

    await db.run(
        `INSERT INTO utilisateur(courriel, mot_de_passe)
        VALUES (?, ?);`,
        [courriel, motDePasseEncrypte]
    )
}

/**
 * Recherche un utilisateur par son identifiant.
 * @param {number} idUtilisateur Identifiant de l'utilisateur.
 * @returns Un utilisateur.
 */
export async function getUtilisateurById(idUtilisateur) {
    const utilisateur = await db.get(
        `SELECT id_utilisateur, courriel, mot_de_passe, niveau_acces 
        FROM utilisateur
        WHERE id_utilisateur = ?;`,
        [idUtilisateur]
    );

    return utilisateur;
}

/**
 * Recherche un utilisateur par son adresse courriel.
 * @param {string} courriel Courriel de l'utilisateur.
 * @returns Un utilisateur.
 */
export async function getUtilisateurByCourriel(courriel) {
    const utilisateur = await db.get(
        `SELECT id_utilisateur, courriel, mot_de_passe, niveau_acces 
        FROM utilisateur
        WHERE courriel = ?;`,
        [courriel]
    );

    return utilisateur;
}
