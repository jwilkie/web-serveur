// Chargement du fichier de configuration
import 'dotenv/config'

// Importations générales du projet
import express, { json } from 'express'
import cors from 'cors'
import helmet from 'helmet'
import compression from 'compression'
import { engine } from 'express-handlebars'
import session from 'express-session'
import memorystore from 'memorystore'
import passport from 'passport'
import './auth.js';
import { addTache, cocheTache, getTaches } from './model/tache.js'
import { courrielValide, idTacheEstValide, motDePasseValide, texteEstValide } from './middlewares/validation.js'
import { addUtilisateur } from './model/utilisateur.js'
import { userAuth, userNotAuth, userNotAuthRedirect } from './middlewares/auth.js'

// Création du serveur
const app = express();

// Initialisation des engins
app.engine('handlebars', engine());
app.set('view engine', 'handlebars');

// Initialisation de la base de données de session
const MemoryStore = memorystore(session);

// Ajout des middlewares
app.use(helmet());
app.use(cors());
app.use(compression());
app.use(json());
app.use(session({
    cookie: { maxAge: 3600000 },
    name: process.env.npm_package_name,
    store: new MemoryStore({ checkPeriod: 3600000 }),
    rolling: true,
    resave: false,
    saveUninitialized: false,
    secret: process.env.SESSION_SECRET
}));
app.use(passport.initialize());
app.use(passport.session());
app.use(express.static('public'));

// Programmation des routes de rendu
app.get('/', async (request, response) => {
    const taches = await getTaches();
    response.render('home', {
        title: 'Liste de tâches | Accueil',
        styles: ['/css/home.css'],
        scripts: ['/js/home.js'],
        taches: taches,
        user: request.user
    });
});

// Route pour la page d'inscription
app.get('/inscription', userNotAuthRedirect, (request, response) => {
    response.render('auth', { 
        title: 'Liste de tâches | Inscription',
        styles: ['/css/auth.css'],
        scripts: ['/js/inscription.js'],
        type: 'Inscription',
        user: request.user
    });
});

// Route pour la page de connexion
app.get('/connexion', userNotAuthRedirect, (request, response) => {
    response.render('auth', { 
        title: 'Liste de tâches | Connexion',
        styles: ['/css/auth.css'],
        scripts: ['/js/connexion.js'],
        type: 'Connexion',
        user: request.user
    });
});

// Programmation des routes dynamiques
// Route retournant la liste des tâches à faire
app.get('/api/taches', async (request, response) => {
    const taches = await getTaches();
    response.status(200).json(taches);
});

// Route ajoutant une tâche à la liste des tâches à faire
app.post('/api/tache', userAuth, texteEstValide, async (request, response) => {
    const idTache = await addTache(request.body.texte);
    response.status(201).json({ idTache });
});

// Route cochant ou décochant une tâche dans la liste des tâches à faire
app.patch('/api/tache', idTacheEstValide, async (request, response) => {
    await cocheTache(request.body.idTache);
    response.status(200).end();
});

// Route pour l'inscription d'un nouvel utilisateur
app.post('/api/inscription', userNotAuth, courrielValide, motDePasseValide, async (request, response, next) => {
    try {
        // Si la validation passe, on crée l'utilisateur
        await addUtilisateur(request.body.courriel, request.body.motDePasse);
        response.sendStatus(201);
    }
    catch (error) {
        // S'il y a une erreur de SQL, on regarde si c'est parce qu'il y a 
        // conflit d'identifiant
        if(error.code === 'SQLITE_CONSTRAINT') {
            response.sendStatus(409);
        }
        else {
            next(error);
        }
    }
});

// Route pour la connexion d'un utilisateur
app.post('/api/connexion', userNotAuth, courrielValide, motDePasseValide, (request, response, next) => {
    // On lance l'authentification avec passport.js
    passport.authenticate('local', (error, user, info) => {
        if (error) {
            // S'il y a une erreur, on laisse Express la gérer
            next(error);
        }
        else if (!user) {
            // Si la connexion échoue, on envoit l'information au client avec 
            // un code 401 (Unauthorized)
            response.status(401).json(info);
        }
        else {
            // Si tout fonctionne, on ajoute l'utilisateur dans la session et 
            // on retourne un code 200 (OK)
            request.logIn(user, (error) => {
                if (error) {
                    // On laisse Express gérer l'erreur
                    next(error);
                }

                response.sendStatus(200);
            });
        }
    })(request, response, next);
});

// Route pour la déconnexion d'un utilisateur
app.post('/api/deconnexion', userAuth, (request, response, next) => {
    // Déconnecter l'utilisateur
    request.logOut((erreur) => {
        if (erreur) {
            // On laisse Express gérer l'erreur
            next(erreur);
        }
        else {
            // Rediriger l'utilisateur vers une autre page
            response.status(200).end();
        }
    });
});

// Démarrage du serveur
app.listen(process.env.PORT);
console.log('Serveur démarré:');
console.log('http://localhost:' + process.env.PORT);