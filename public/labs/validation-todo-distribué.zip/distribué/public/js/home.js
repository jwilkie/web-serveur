/**
 * <ul> contenant la liste des tâches à accomplir.
 */
const listeTache = document.getElementById('liste-tache');

/**
 * <form> pour ajouter une tâche dans la liste.
 */
const formTache = document.getElementById('form-tache');

/**
 * <input> pour spécifier le texte de la tâche à ajouter.
 */
const texteTache = document.getElementById('texte-tache');

/**
 * Liste de tous les <input type="checkbox"> de la liste de tâche qui sont 
 * présent au chargement de la page (prégénéré par handlebars)
 */
const checkboxes = document.querySelectorAll('#liste-tache input[type=checkbox]');

/**
 * Ajoute une tâche dans la liste dans l'interface graphique.
 * @param {number} index Index de la tâche sur le serveur.
 * @param {string} texte Texte de la tâche.
 * @param {boolean} estFait Valeur indiquant si la tâche est accomplie ou non.
 */
function addTacheClient(idTache, texte, estFait) {
    // La structure d'une tâche dans l'interface graphique est la suivante:
    // <li>
    //     <label>
    //         <input type="checkbox" data-index="<INDEX_TACHE>">
    //         Texte de la tâche à faire ici
    //     </label>
    // </li>
    // Le code suivant construit cette structure

    // Création du <li>
    const li = document.createElement('li');

    // Création du <label>
    const label = document.createElement('label');
    li.append(label);

    // Création du <input type="checkbox">
    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.checked = estFait;
    checkbox.dataset.idTache = idTache;
    checkbox.addEventListener('change', cocheTacheServeur);
    label.append(checkbox);

    // Création du texte
    const contenu = document.createTextNode(texte);
    label.append(contenu);

    // Ajouter la tâche dans la liste
    listeTache.append(li);
}

/**
 * Envoie une requête pour ajouter une tâche dans la liste du serveur. Si la
 * tâche est correctement ajouté sur le serveur, on l'ajoutera aussi dans 
 * l'interface graphique.
 * @param {SubmitEvent} event Évènement de soumission du formulaire.
 */
async function addTacheServeur(event) {
    event.preventDefault();

    // Préparation des données
    const data = {
        texte: texteTache.value
    };

    // Envoyer de la requête
    const response = await fetch('/api/tache', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    });

    // Traitement de la réponse
    if(response.ok) {
        // Ajouter la tâche dans l'interface graphique
        const valeur = await response.json();
        addTacheClient(valeur.idTache, data.texte, false);

        // Vider le formulaire et remettre le focus sur le champ de texte
        texteTache.value = '';
        texteTache.focus();
    }
}

/**
 * Envoie une requête pour cocher ou décocher un tâche dans la liste du 
 * serveur web. S
 * @param {Event} event Évènement de changement de l'état de la case à cocher.
 */
async function cocheTacheServeur(event) {
    // Préparation des données
    const data = {
        idTache: event.currentTarget.dataset.idTache
    };

    // Envoyer de la requête
    const response = await fetch('/api/tache', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    });

    // Traitement de la réponse
    if(response.ok) {
        // Rien à faire ici pour l'instant
    }
}

// Code à exécuter au démarrage de la page
// Détection de la soumission du formulaire
formTache.addEventListener('submit', addTacheServeur);

// Détection du changement d'état des cases à coché
for(let checkbox of checkboxes) {
    checkbox.addEventListener('change', cocheTacheServeur);
}
