export const triABulle = (tableau) => {
    for (let i = 0; i < tableau.length; i++) {
        for (let j = 0; j < tableau.length - i; j++) {
            if (tableau[j] > tableau[j + 1]) {
                let temp = tableau[j];
                tableau[j] = tableau[j + 1];
                tableau[j + 1] = temp;
            }
        }
    }

    return tableau;
}
