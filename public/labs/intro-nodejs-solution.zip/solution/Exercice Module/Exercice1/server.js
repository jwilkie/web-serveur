import { triABulle } from './triage.js';

const tableauNonTrie = [-33, 2, 33, 44, 1, 222, -333, 7743, 3432];
console.log("Tableau non trié: " + tableauNonTrie);

let tableauTrie = triABulle(tableauNonTrie);
console.log("Tableau trié: " + tableauTrie);
