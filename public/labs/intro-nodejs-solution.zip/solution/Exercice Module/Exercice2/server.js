import { estPremier } from './premier.js';

console.log('Nombres premiers entre 2 et 1000:');

let affichage = '';
let quantite = 0;
for (let i = 2; i < 1000; i++) {
    if (estPremier(i)) {
        affichage += (i + ', ').padStart(6);
        quantite++;

        if (quantite % 10 === 0) {
            affichage += '\n'
        }
    }
}

console.log(affichage);