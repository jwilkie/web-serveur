export function estPremier(nombre) {
    if (nombre > 1) {
        for (let i = 2; i < nombre; i++) {
            if (nombre % i === 0) {
                return false;
            }
        }

        return true;
    }

    return false;
}