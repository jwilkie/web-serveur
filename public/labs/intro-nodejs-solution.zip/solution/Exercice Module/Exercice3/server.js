import { createInterface } from "readline/promises";
import { creerSequence } from "./sequence.js";
import { afficherPalmares, estDansPalmares, ajouterPalmares } from "./palmares.js";

let readInterface = createInterface({
    input: process.stdin,
    output: process.stdout
});

let sequences = [];
for (let i = 0; i < 1; i++) {
    sequences.push(creerSequence());
}

console.log("Entrez les lignes suivantes dans la console le plus rapidement possible!");
await readInterface.question("Appuyez sur la touche \"Entrer\" pour commencer!");

let chronometre = Date.now();

for (let i = 0; i < sequences.length; i++) {
    console.log("\n" + sequences[i]);
    console.log("----------");

    let ligne;
    do {
        ligne = await readInterface.question("");
        if (ligne !== sequences[i]) {
            console.log("Erreur! Réessayez!");
        }
    } while (ligne !== sequences[i]);
}

let tempsFinal = ((Date.now() - chronometre) / 1000).toFixed(2);
console.log("\n\nTemps final: " + tempsFinal + " secondes");

if (estDansPalmares(tempsFinal)) {
    console.log("Meilleur score!");
    let nom = await readInterface.question("Entrez votre nom: ");
    ajouterPalmares(nom, tempsFinal)
}

afficherPalmares();

readInterface.close();
