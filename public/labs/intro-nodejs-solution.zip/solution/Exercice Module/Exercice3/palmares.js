import { readFile, writeFile } from "fs/promises";

let data = await readFile("./palmares.txt");
let palmares = data.toString().split("\r\n");
for (let i = 0; i < palmares.length; i++) {
    palmares[i] = palmares[i].split(":");
}

const sauvegardePalmares = () => {
    let texte = "";
    for (let i = 0; i < palmares.length; i++) {
        texte += palmares[i][0] + ":" + palmares[i][1] + "\r\n";
    }

    writeFile("palmares.txt", texte);
}

export const afficherPalmares = () => {
    console.log("=========+======================+======");
    console.log("POSITION | NOM                  | TEMPS");
    console.log("=========+======================+======");
    for (let i = 0; i < palmares.length; i++) {
        console.log(
            (i + 1).toString().padEnd(8) + " | " +
            palmares[i][0].padEnd(20) + " | " +
            palmares[i][1].padStart(5)
        );
    }
}

export const estDansPalmares = (temps) => {
    return Number(temps) < Number(palmares[palmares.length - 1][1]);
}

export const ajouterPalmares = (nom, temps) => {
    if (estDansPalmares(temps)) {
        palmares[palmares.length - 1] = [nom, temps]

        for (let i = palmares.length - 1; i > 0 && Number(palmares[i][1]) < Number(palmares[i - 1][1]); i--) {
            let temp = palmares[i - 1];
            palmares[i - 1] = palmares[i];
            palmares[i] = temp;
        }

        sauvegardePalmares();
    }
}
