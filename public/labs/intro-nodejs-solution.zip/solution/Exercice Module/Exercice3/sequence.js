export const creerSequence = () => {
    let a = "a".charCodeAt(0);
    let z = "z".charCodeAt(0);

    let sequence = "";
    for (let i = 0; i < 10; i++) {
        let codeCaractere = Math.floor(Math.random() * (z - a)) + a;
        sequence += String.fromCharCode(codeCaractere);
    }

    return sequence;
}
