/**
 * Tableau de tâches à faire.
 */
let taches = [
    {
        texte: 'Suivre le cours',
        estFait: true
    },
    {
        texte: 'Faire le laboratoire',
        estFait: false
    }
];

/**
 * Retourne la liste des tâches à faire.
 * @returns La liste des tâches à faire.
 */
export function getTaches() {
    return taches;
}

/**
 * Ajoute une tache à faire dans la liste.
 * @param {string} texte Texte de la nouvelle tâche à faire.
 */
export function addTache(texte) {
    taches.push({
        texte: texte,
        estFait: false
    });
}

/**
 * Coche ou décoche une tâche dans la liste de tâches à faire.
 * @param {number} index Index de la tâche à cocher ou décocher dans la liste.
 */
export function cocheTache(index) {
    taches[index].estFait = !taches[index].estFait;
}