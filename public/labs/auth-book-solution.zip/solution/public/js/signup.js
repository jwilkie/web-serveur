import { isEmailValid, isPasswordValid } from './validation.js';

const inputEmail = document.getElementById('input-email');
const inputPassword = document.getElementById('input-password');
const formAuth = document.getElementById('form-auth');
const errors = document.getElementById('errors');

async function signup(event) {
    event.preventDefault();

    // Préparation des données
    const data = {
        email: inputEmail.value,
        password: inputPassword.value
    };

    // Réinitialiser les erreurs
    errors.innerText = '';

    // Validation cliente
    if(!isEmailValid(data.email)) {
        errors.innerText = 'Le courriel n\'est pas valide.';
        return;
    }

    if(!isPasswordValid(data.password)) {
        errors.innerText = 'Le mot de passe doit contenir au moins 8 caractères.';
        return;
    }

    // Envoyer la requête au serveur
    let response = await fetch('/api/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    });

    // Traitement de la réponse
    if (response.ok) {
        // Redirection vers la page de connexion
        window.location.replace('/login');
    }
    else if(response.status === 409) {
        errors.innerText = 'Un compte avec ce courriel existe déjà.';
    }   
};

formAuth.addEventListener('submit', signup);