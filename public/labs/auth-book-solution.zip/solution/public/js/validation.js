/**
 * Valide un ISBN.
 * @param {string} isbn Le ISBN à valider.
 * @returns Une valeur indiquant si le ISBN est valide ou non.
 */
export const isIsbnValid = (isbn) => 
    typeof isbn === 'string' && 
    (
        isbn.replace('-', '').length === 10 ||
        isbn.replace('-', '').length === 13
    );

/**
 * Valide un titre de livre.
 * @param {string} title Le titre à valider.
 * @returns Une valeur indiquant si le titre est valide ou non.
 */
export const isTitleValid = (title) => 
    typeof title === 'string' &&
    title !== '';

/**
 * Valide un nombre de pages.
 * @param {string} nbPages Le nombre de pages à valider.
 * @returns Une valeur indiquant si le nombre de pages est valide ou non.
 */
export const isNbPageValid = (nbPages) => 
    typeof nbPages === 'number' &&
    Number.isInteger(nbPages) &&
    nbPages > 0;

/**
 * Valide un sommaire.
 * @param {string} summary Le sommaire à valider.
 * @returns Une valeur indiquant si le sommaire est valide ou non.
 */
export const isSummaryValid = (summary) => 
    typeof summary === 'string' &&
    summary !== '';

/**
 * Valide une liste d'auteurs.
 * @param {string} authors La liste d'auteurs à valider.
 * @returns Une valeur indiquant si la liste d'auteurs est valide ou non.
 */
export const areAuthorsValid = (authors) => 
    Array.isArray(authors) &&
    authors.length > 0 &&
    authors.every((author) => 
        typeof author === 'string' &&
        author !== ''
    );

/**
 * Valide une liste de catégories.
 * @param {string} categories La liste de catégories à valider.
 * @returns Une valeur indiquant si la liste de catégories est valide ou non.
 */
export const areCategoriesValid = (categories) => 
    Array.isArray(categories) &&
    categories.length > 0 &&
    categories.every((category) => 
        typeof category === 'string' &&
        category !== ''
    );

/**
 * Valide une adresse courriel.
 * @param {string} email Le courriel à valider.
 * @returns Une valeur indiquant si le courriel est valide ou non.
 */
export const isEmailValid = (email) =>
    typeof email === 'string' &&
    email.match(/^(?:[a-z0-9!#$%&'*+\x2f=?^_`\x7b-\x7d~\x2d]+(?:.[a-z0-9!#$%&'*+\x2f=?^_`\x7b-\x7d~\x2d]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[a-z0-9](?:[a-z0-9\x2d]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9\x2d]*[a-z0-9])?|\[(?:(?:(2(5[0-5]|[0-4][0-9])|1[0-9][0-9]|[1-9]?[0-9]))\.){3}(?:(2(5[0-5]|[0-4][0-9])|1[0-9][0-9]|[1-9]?[0-9])|[a-z0-9\x2d]*[a-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\[\x01-\x09\x0b\x0c\x0e-\x7f])+)])$/i)

/**
 * Valide un mot de passe.
 * @param {string} password Le mot de passe à valider
 * @returns Une valeur indiquant si le mot de passe est valide ou non.
 */
export const isPasswordValid = (password) => 
    typeof password === 'string' && 
    password.length >= 8;