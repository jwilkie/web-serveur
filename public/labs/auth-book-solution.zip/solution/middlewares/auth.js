// Middleware qui valide que l'utilisateur est connecté
export function userAuth(request, response, next) {
    if(request.user) {
        return next();
    }

    response.status(401).end();
}

// Middleware qui valide que l'utilisateur n'est pas connecté
export function userNotAuth(request, response, next) {
    if(!request.user) {
        return next();
    }

    response.status(401).end();
}

// Middleware qui valide que l'utilisateur est connecté pour les pages
export function userAuthRedirect(request, response, next) {
    if(request.user) {
        return next();
    }

    response.status(401).redirect('/login');
}

// Middleware qui valide que l'utilisateur n'est pas connecté pour les pages
export function userNotAuthRedirect(request, response, next) {
    if(!request.user) {
        return next();
    }

    response.status(401).redirect('/');
}

// Middleware qui valide que l'utilisateur est administrateur
export function userAdmin(request, response, next) {
    if(request.user && request.user.is_admin) {
        return next();
    }

    response.status(401).end();
}
