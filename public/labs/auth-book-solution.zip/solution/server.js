// Chargement du fichier de configuration
import 'dotenv/config'

// Importations générales du projet
import express, { json } from 'express'
import cors from 'cors'
import helmet from 'helmet'
import compression from 'compression'
import { engine } from 'express-handlebars'
import session from 'express-session'
import memorystore from 'memorystore'
import passport from 'passport'
import './auth.js';
import { addBook, deleteBook, getAllISBNAndTitle, getBookByISBN, modifyBook } from './model/book.js'
import { bookIsValid, emailIsValid, isbnIsValid, isbnQueryIsValid, passwordIsValid } from './middlewares/validation.js'
import { addUser } from './model/user.js'
import { userAdmin, userAuth, userAuthRedirect, userNotAuth, userNotAuthRedirect } from './middlewares/auth.js'

// Création du serveur
const app = express();

// Initialisation des engins
app.engine('handlebars', engine());
app.set('view engine', 'handlebars');

// Initialisation de la base de données de session
const MemoryStore = memorystore(session);

// Ajout des middlewares
app.use(helmet());
app.use(cors());
app.use(compression());
app.use(json());
app.use(session({
    cookie: { maxAge: 3600000 },
    name: process.env.npm_package_name,
    store: new MemoryStore({ checkPeriod: 3600000 }),
    resave: false,
    saveUninitialized: false,
    rolling: true,
    secret: process.env.SESSION_SECRET
}));
app.use(passport.initialize());
app.use(passport.session());
app.use(express.static('public'));

// Programmation des routes de rendu
app.get('/', userAuthRedirect, async (request, response) => {
    const books = await getAllISBNAndTitle();

    response.render('home', {
        title: 'Bibliothèque | Accueil',
        styles: ['/css/home.css'],
        scripts: ['/js/home.js'],
        books: books,
        user: request.user,
        isAdmin: request.user && request.user.is_admin
    });
});

// Route pour la page d'inscription
app.get('/signup', userNotAuthRedirect, (request, response) => {
    response.render('auth', { 
        title: 'Bibliothèque | Inscription',
        styles: ['/css/auth.css'],
        scripts: ['/js/signup.js'],
        type: 'Inscription' 
    });
});

// Route pour la page de connexion
app.get('/login', userNotAuthRedirect, (request, response) => {
    response.render('auth', { 
        title: 'Bibliothèque | Connexion',
        styles: ['/css/auth.css'],
        scripts: ['/js/login.js'],
        type: 'Connexion' 
    });
});

// Programmation des routes
// Route pour obtenir la liste des livres (ISBN et titre seulement)
app.get('/api/books', userAuth, async (request, response) => {
    const list = await getAllISBNAndTitle();
    response.status(200).json(list);
});

// Route pour ajouter un livre
app.post('/api/book', userAdmin, bookIsValid, async (request, response) => {
    try {
        await addBook(request.body.book);
        response.status(201).end();
    }
    catch(error) {
        if(error.code === 'SQLITE_CONSTRAINT') {
            response.status(409).end();
        }
    }
});

// Route pour obtenir un livre à partir de son ISBN
app.get('/api/book', userAuth, isbnQueryIsValid, async (request, response) => {
    const book = await getBookByISBN(request.query.isbn);
    if(book) {
        response.status(200).json(book);
    }
    else {
        response.status(404).end();
    }
});

// Route pour modifier un livre à partir de son ISBN
app.put('/api/book', userAdmin, isbnIsValid, bookIsValid, async (request, response) => {
    await modifyBook(request.body.isbn, request.body.book);
    response.status(200).end();
});

// Route pour supprimer un livre à partir de son ISBN
app.delete('/api/book', userAdmin, isbnIsValid, async (request, response) => {
    await deleteBook(request.body.isbn);
    response.status(200).end();
});

// Route pour l'inscription
app.post('/api/signup', userNotAuth, emailIsValid, passwordIsValid, async (request, response, next) => {
    try {
        await addUser(request.body.email, request.body.password);
        response.sendStatus(201);
    }
    catch (error) {
        // Courriel déjà existant
        if(error.code === 'SQLITE_CONSTRAINT') {
            response.sendStatus(409);
        }
        else {
            next(error);
        }
    }
});

// Route pour la connexion
app.post('/api/login', userNotAuth, emailIsValid, passwordIsValid, (request, response, next) => {
    passport.authenticate('local', (error, user, info) => {
        if (error) {
            next(error);
        }
        else if (!user) {
            response.status(401).json(info);
        }
        else {
            request.logIn(user, (error) => {
                if (error) {
                    next(error);
                }

                response.sendStatus(200);
            });
        }
    })(request, response, next);
});

// Route pour la déconnexion
app.post('/api/logout', userAuth, (request, response, next) => {
    request.logOut((erreur) => {
        if (erreur) {
            next(erreur);
        }
        else {
            response.status(200).end();
        }
    });
});

// Démarrage du serveur
app.listen(process.env.PORT);
console.log('Serveur démarré:');
console.log('http://localhost:' + process.env.PORT);