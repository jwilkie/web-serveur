import { db } from '../db/db.js'
import bcrypt from 'bcrypt'

/**
 * Ajoute un nouvel utilisateur.
 * @param {string} email Courriel du nouvel utilisateur.
 * @param {string} password Mot de passe du nouvel utilisateur.
 */
export async function addUser(email, password) {
    let passwordHash = await bcrypt.hash(password, 10);

    await db.run(
        `INSERT INTO user(email, password)
        VALUES (?, ?);`,
        [email, passwordHash]
    )
}

/**
 * Recherche un utilisateur par son identifiant.
 * @param {number} id Identifiant de l'utilisateur à rechercher.
 * @returns Un utilisateur ou undefined si aucun utilisateur n'est trouvé.
 */
export async function getUserById(id) {
    const user = await db.get(
        `SELECT id_user, email, password, is_admin 
        FROM user
        WHERE id_user = ?;`,
        [id]
    );

    return user;
}

/**
 * Recherche un utilisateur par son courriel.
 * @param {string} email Le courriel de l'utilisateur à rechercher.
 * @returns Un utilisateur ou undefined si aucun utilisateur n'est trouvé.
 */
export async function getUserByEmail(email) {
    const user = await db.get(
        `SELECT id_user, email, password, is_admin 
        FROM user
        WHERE email = ?;`,
        [email]
    );

    return user;
}