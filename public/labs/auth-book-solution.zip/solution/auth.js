import bcrypt from 'bcrypt'
import passport from 'passport'
import { Strategy } from 'passport-local'
import { getUserById, getUserByEmail } from './model/user.js'

// Configuration générale de la stratégie.
const config = {
    usernameField: 'email',
    passwordField: 'password'
};

// Configuration de la stratégie d'authentification locale
passport.use(new Strategy(config, async (email, password, done) => {
    try {
        // Validate that user exists
        const user = await getUserByEmail(email);
        if (!user) {
            return done(null, false, { error: 'wrong_user' });
        }

        // Validate that password match the one in the database
        const isValid = await bcrypt.compare(password, user.password);
        if (!isValid) {
            return done(null, false, { error: 'wrong_password' });
        }

        return done(null, user);
    }
    catch (error) {
        return done(error);
    }
}));

// Serialise l'identifiant de l'utilisateur dans la session
passport.serializeUser((user, done) => {
    done(null, user.id_user);
});

// Désérialise l'utilisateur en allant le chercher dans la base de données
passport.deserializeUser(async (id, done) => {
    try {
        const user = await getUserById(id);
        done(null, user);
    }
    catch (error) {
        done(error);
    }
});