const btnLogout = document.getElementById('btn-logout');

async function logout() {
    let response = await fetch('/api/logout', {
        method: 'POST'
    });

    if (response.ok) {
        // Redirection vers la page de connexion
        window.location.replace('/login');
    }
}

if(btnLogout) {
    btnLogout.addEventListener('click', logout);
}