import { isEmailValid, isPasswordValid } from './validation.js';

const inputEmail = document.getElementById('input-email');
const inputPassword = document.getElementById('input-password');
const formAuth = document.getElementById('form-auth');
const errors = document.getElementById('errors');

async function login(event) {
    event.preventDefault();

    // Préparation des données
    const data = {
        email: inputEmail.value,
        password: inputPassword.value
    };

    // Réinitialiser les erreurs
    errors.innerText = '';

    // Validation cliente
    if(!isEmailValid(data.email)) {
        errors.innerText = 'Le courriel n\'est pas valide.';
        return;
    }

    if(!isPasswordValid(data.password)) {
        errors.innerText = 'Le mot de passe doit contenir au moins 8 caractères.';
        return;
    }

    // Envoyer la requête au serveur
    let response = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    });

    // Traitement de la réponse
    if (response.ok) {
        // Redirection vers la page d'accueil
        window.location.replace('/');
    }
    else if(response.status === 401) {
        let data = await response.json()
        
        if(data.error === 'wrong_user') {
            errors.innerText = 'Aucun compte ne correspond à ce courriel.';
        }
        else if(data.error === 'wrong_password') {
            errors.innerText = 'Le mot de passe est incorrect.';
        }
    }   
};

formAuth.addEventListener('submit', login);