/**
 * Middleware pour s'assurer que l'utilisateur accédant à une route d'API est 
 * connecté.
 * @param {import("express").Request} request 
 * @param {import("express").Response} response 
 * @param {import("express").NextFunction} next 
 */
export function userAuth(request, response, next) {
    if(request.user) {
        return next();
    }

    response.status(401).end();
}

/**
 * Middleware pour s'assurer que l'utilisateur accédant à une route d'API 
 * n'est pas connecté.
 * @param {import("express").Request} request 
 * @param {import("express").Response} response 
 * @param {import("express").NextFunction} next 
 */
export function userNotAuth(request, response, next) {
    if(!request.user) {
        return next();
    }

    response.status(401).end();
}

/**
 * Middleware pour les routes de page qui ne doivent pas être accédé par des 
 * utilisateurs connecté
 * @param {import("express").Request} request 
 * @param {import("express").Response} response 
 * @param {import("express").NextFunction} next 
 */
export function userNotAuthRedirect(request, response, next) {
    if(!request.user) {
        return next();
    }

    response.status(401).redirect('/');
}
