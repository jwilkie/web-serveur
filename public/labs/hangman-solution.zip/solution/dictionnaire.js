import { readFile } from 'node:fs/promises';

/**
 * Pour avoir le dictionnaire, on exécute les étapes suivantes:
 * 1. On va lire le fichier "liste-français.txt"
 * 2. On enlève tous les caractères accentués et on les remplace par leur 
 *    version sans accents
 * 3. On mets tout le texte en majuscule
 * 4. On sépare les mots dans un tableau
 * 5. On enlève les mots ayant moins de 4 caractères de long
 */

// Méthode utilisant le await
let donnees = await readFile('./liste-francais.txt');
let texte = donnees.toString();
let texteNormalise = texte.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
let texteMajuscule = texteNormalise.toUpperCase();
let listeMots = texteMajuscule.split('\r\n');
let dictionnaire = listeMots.filter((word) => word.length >= 4);

// Méthode utilisant la fonction then des promesses
// let dictionary = await readFile('./liste_francais.txt')
//     .then((data) => data.toString())
//     .then((text) => text.normalize('NFD').replace(/[\u0300-\u036f]/g, ''))
//     .then((textNormalize) => textNormalize.toUpperCase())
//     .then((textNormalizeUpper) => textNormalizeUpper.split('\r\n'))
//     .then((wordList) => wordList.filter((word) => word.length >= 4));

// On exporte la promesse qui sera résolue une fois que toutes les étapes à 
// faire sur le dictionnaire seront faites
export { dictionnaire };
