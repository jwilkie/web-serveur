import { createInterface } from 'node:readline/promises';
import { dictionnaire } from './dictionnaire.js'

// Création de l'interface de lecture
const readInterface = createInterface({
    input: process.stdin,
    output: process.stdout
});

// Prendre un mot aléatoire du dictionnaire
let motAleatoire = dictionnaire[Math.floor(Math.random() * dictionnaire.length)];

// On crée le mot caché en remplaçant les lettres alphabétiques par des 
// barres de soulignement
let motCache = motAleatoire.replace(/[A-Z]/g, '_').split('');

// On boucle tant que l'utilisateur n'a pas trouvé le mot
let nombreEssais = 0;
while (motCache.join('') !== motAleatoire) {
    // On vide la console entre les essais
    console.clear();

    // Afficher le nombre d'essai
    console.log(`Nombre d'essais: ${nombreEssais}\n`);

    // Afficher le mot
    console.log(motCache.join(' '));

    // Demande d'entrée d'un caractère
    let caractere = await readInterface.question('\n\nEntrez un caractère: ');

    // On regarde si l'utilisateur a bien entrée une valeur
    if (caractere) {
        caractere = caractere[0].toUpperCase()

        // On regarde si la lettre entrée existe dans le mot original
        let estTrouve = false;
        for (let i = 0; i < motAleatoire.length; i++) {
            // Si la lettre est trouvé, on l'ajoute dans notre mot caché
            if (caractere === motAleatoire[i]) {
                estTrouve = true;
                motCache[i] = motAleatoire[i];
            }
        }

        // Si la lettre n'est pas trouvé, on augmente notre notre d'essais
        if (!estTrouve) {
            nombreEssais++;
        }
    }
}

// Afficher le mot final une fois trouvé
console.clear();
console.log('\n\n' + motCache.join(' '));
console.log(`\n\nVous avez réussi à trouver le mot en ${nombreEssais} essai${nombreEssais > 1 ? 's' : ''}`);
readInterface.close();
